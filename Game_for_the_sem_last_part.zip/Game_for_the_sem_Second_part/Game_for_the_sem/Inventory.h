#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include "Rune.h"

class Inventory {

	Rune* runes;
	int current; //amount of elements in runes
	int capacity; //max available elements in runes

	void copy(const Inventory& other) {

		this->current = other.current;
		this->capacity = other.capacity;

		this->runes = new Rune[capacity];
		for (int i = 0; i <= current; i++)
		{
			this->runes[i] = other.runes[i];
		}
	}
	
	void remove() {
		delete runes;
	}

public:
	Inventory();
	Inventory(Rune*, int, int);
	Inventory(const Inventory& other);

	Inventory& operator=(const Inventory& other);

	void resize();
	void add(Rune const&);
	void setRunes(Rune*, int);

	~Inventory();
};