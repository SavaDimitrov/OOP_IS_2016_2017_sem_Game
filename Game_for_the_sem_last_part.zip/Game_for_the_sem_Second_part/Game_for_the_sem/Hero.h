#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>

using namespace std;

class Hero {
	char* name;
	int health;
	unsigned level;
	unsigned experience;
	int strength;
	int speed;
	int intellect;

public:

	Hero();
	Hero(Hero const& other);
	Hero(char*, int, unsigned, unsigned, int, int, int);

	char* getName() const;
	int getHealth() const;
	unsigned getLevel() const;
	unsigned getExperience() const;
	int getStrength() const;
	int getSpeed() const;
	int getIntellect() const;

	void setName(char*);
	void sethealth(int);
	void setLevel(unsigned);
	void setExperience(unsigned);
	void setStrength(int);
	void setSpeed(int);
	void setIntellect(int);
	
	void heroDescription();
};